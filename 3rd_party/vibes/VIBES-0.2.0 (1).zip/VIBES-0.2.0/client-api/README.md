VIBes client API
================
API to access vibes from different languages.
Add language specific API files to a subdirectory of this folder.
