VIBes viewer
============
Server side of the VIBes system.

